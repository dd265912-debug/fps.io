// mapBuilder.js
// Builds the "Meridian District" map: a cyberpunk skyline fused with
// classical colonnades, laid out as a tactical map with a mid structure,
// lane-dividing walls, scattered cover crates, and two bomb sites (A/B).
// Returns the list of box colliders so main.js can build matching
// cannon-es static bodies for collision.

import * as THREE from 'three';

// World-space site rectangles. MUST mirror server.js SITE_ZONES exactly —
// both the client (plant/defuse prompts) and server (validation) rely on
// these lining up.
export const SITE_ZONES = {
  A: { minX: 18, maxX: 34, minZ: -34, maxZ: -18 },
  B: { minX: -34, maxX: -18, minZ: -34, maxZ: -18 },
};

export function buildMap(scene) {
  const colliders = []; // { size: THREE.Vector3, position: THREE.Vector3 } — for cannon-es bodies
  const collidableMeshes = []; // actual THREE.Mesh refs — for camera line-of-sight raycasts

  scene.background = new THREE.Color(0x0a0e14);
  scene.fog = new THREE.Fog(0x0a0e14, 45, 150);

  // ---------------- Lighting ----------------
  const sun = new THREE.DirectionalLight(0xfff2df, 1.8);
  sun.position.set(-40, 60, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -75;
  sun.shadow.camera.right = 75;
  sun.shadow.camera.top = 75;
  sun.shadow.camera.bottom = -75;
  sun.shadow.camera.far = 200;
  sun.shadow.bias = -0.0004;
  scene.add(sun);
  scene.add(sun.target);

  scene.add(new THREE.AmbientLight(0x8899aa, 0.45));
  scene.add(new THREE.HemisphereLight(0x224466, 0x120018, 0.55));

  const neonA = new THREE.PointLight(0x38f2ff, 8, 34, 2);
  neonA.position.set(26, 5, -26);
  scene.add(neonA);
  const neonB = new THREE.PointLight(0xff3860, 8, 34, 2);
  neonB.position.set(-26, 5, -26);
  scene.add(neonB);
  const midGlow = new THREE.PointLight(0x9d6bff, 5, 26, 2);
  midGlow.position.set(0, 6, 0);
  scene.add(midGlow);

  // ---------------- Ground ----------------
  const groundMat = new THREE.MeshStandardMaterial({ color: 0x1c2230, roughness: 0.88, metalness: 0.1 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(150, 150), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(150, 75, 0x2a3a55, 0x18202e);
  grid.position.y = 0.01;
  scene.add(grid);

  // ---------------- Helpers ----------------
  function addBox(w, h, d, x, y, z, color, opts = {}) {
    const mat = new THREE.MeshStandardMaterial({
      color,
      roughness: opts.roughness ?? 0.6,
      metalness: opts.metalness ?? 0.2,
      emissive: opts.emissive ?? 0x000000,
      emissiveIntensity: opts.emissiveIntensity ?? 0,
    });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    colliders.push({ size: new THREE.Vector3(w, h, d), position: new THREE.Vector3(x, y, z) });
    collidableMeshes.push(mesh);
    return mesh;
  }

  // ---------------- Perimeter walls ----------------
  addBox(150, 10, 1.5, 0, 5, 75, 0x2b3348);
  addBox(150, 10, 1.5, 0, 5, -75, 0x2b3348);
  addBox(1.5, 10, 150, 75, 5, 0, 0x2b3348);
  addBox(1.5, 10, 150, -75, 5, 0, 0x2b3348);

  // ---------------- Central colonnade (cyberpunk + classical fusion) ----------------
  for (let i = -2; i <= 2; i++) {
    addBox(2, 9, 2, i * 8, 4.5, 0, 0xcac2ad, { roughness: 0.4, metalness: 0.05 }); // marble-ish columns
  }
  addBox(42, 0.6, 10, 0, 9, 0, 0xe7e1cf, { roughness: 0.4 }); // architrave roof strip
  addBox(42, 0.15, 10.2, 0, 8.6, 0, 0x38f2ff, { emissive: 0x38f2ff, emissiveIntensity: 2.2 }); // neon strip

  // ---------------- Cover crates ----------------
  const cratePositions = [
    [10, -10], [14, -6], [-10, -10], [-14, -6],
    [22, -8], [-22, -8], [6, -28], [-6, -28],
    [30, -30], [-30, -30], [0, -50], [0, 50],
    [10, 22], [-10, 22], [20, 42], [-20, 42],
  ];
  cratePositions.forEach(([x, z], i) => {
    const h = 1.6 + (i % 3) * 0.4;
    addBox(2.2, h, 2.2, x, h / 2, z, 0x3f4a5c, { roughness: 0.9, metalness: 0.3 });
  });

  // ---------------- Lane-dividing walls (mid / A lane / B lane) ----------------
  addBox(1.2, 3, 22, 16, 1.5, -25, 0x2b3348);
  addBox(1.2, 3, 22, -16, 1.5, -25, 0x2b3348);
  addBox(16, 3, 1.2, 26, 1.5, -14, 0x2b3348);
  addBox(16, 3, 1.2, -26, 1.5, -14, 0x2b3348);

  // ---------------- Bomb site markers ----------------
  addSiteMarker(scene, 'A', SITE_ZONES.A, 0x38f2ff);
  addSiteMarker(scene, 'B', SITE_ZONES.B, 0xff3860);

  // ---------------- Spawn platforms (visual only, non-colliding) ----------------
  const atkPad = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 8),
    new THREE.MeshStandardMaterial({ color: 0x4a2431, emissive: 0xff2255, emissiveIntensity: 0.45, roughness: 0.5 })
  );
  atkPad.rotation.x = -Math.PI / 2;
  atkPad.position.set(0, 0.02, 40);
  scene.add(atkPad);

  const defPad = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 8),
    new THREE.MeshStandardMaterial({ color: 0x24314a, emissive: 0x2255ff, emissiveIntensity: 0.45, roughness: 0.5 })
  );
  defPad.rotation.x = -Math.PI / 2;
  defPad.position.set(0, 0.02, -40);
  scene.add(defPad);

  return { colliders, collidableMeshes };
}

function addSiteMarker(scene, label, zone, color) {
  const w = zone.maxX - zone.minX;
  const d = zone.maxZ - zone.minZ;
  const cx = (zone.minX + zone.maxX) / 2;
  const cz = (zone.minZ + zone.maxZ) / 2;

  const mat = new THREE.MeshStandardMaterial({
    color, transparent: true, opacity: 0.28, emissive: color, emissiveIntensity: 0.8, side: THREE.DoubleSide,
  });
  const marker = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
  marker.rotation.x = -Math.PI / 2;
  marker.position.set(cx, 0.03, cz);
  scene.add(marker);

  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.font = 'bold 96px Orbitron, sans-serif';
  ctx.fillStyle = `#${color.toString(16).padStart(6, '0')}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 64, 68);
  const tex = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  sprite.scale.set(6, 6, 1);
  sprite.position.set(cx, 4, cz);
  scene.add(sprite);
}
