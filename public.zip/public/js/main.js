// main.js
// Entry point: wires together the Three.js scene, cannon-es physics,
// pointer-lock FPS controls, the buy-phase economy UI, and the
// Socket.io network layer.

import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import * as CANNON from 'cannon-es';

import { NetworkManager } from './network.js';
import { buildMap, SITE_ZONES } from './mapBuilder.js';
import { RemotePlayer, createPlayerMesh } from './players.js';
import { getWeapon } from './weapons.js';
import { initShop, refreshShopAffordability, openShop, closeShop } from './economy.js';
import * as HUD from './hud.js';

// ---------------- Renderer / Scene / Camera ----------------
const canvas = document.getElementById('game-canvas');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(78, window.innerWidth / window.innerHeight, 0.1, 300);

const { colliders, collidableMeshes } = buildMap(scene);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ---------------- Physics world (cannon-es) ----------------
const world = new CANNON.World({ gravity: new CANNON.Vec3(0, -22, 0) });
world.broadphase = new CANNON.SAPBroadphase(world);
world.allowSleep = false;

const groundBody = new CANNON.Body({ type: CANNON.Body.STATIC, shape: new CANNON.Plane() });
groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
world.addBody(groundBody);

colliders.forEach((c) => {
  const shape = new CANNON.Box(new CANNON.Vec3(c.size.x / 2, c.size.y / 2, c.size.z / 2));
  const body = new CANNON.Body({ type: CANNON.Body.STATIC, shape });
  body.position.set(c.position.x, c.position.y, c.position.z);
  world.addBody(body);
});

const PLAYER_RADIUS = 0.4;
const PLAYER_HEIGHT = 1.8;
const playerBody = new CANNON.Body({
  mass: 75,
  shape: new CANNON.Cylinder(PLAYER_RADIUS, PLAYER_RADIUS, PLAYER_HEIGHT, 8),
  fixedRotation: true,
  linearDamping: 0.001,
});
playerBody.position.set(0, 40, 40);
world.addBody(playerBody);

// ---------------- Pointer-lock FPS controls ----------------
const controls = new PointerLockControls(camera, document.body);
scene.add(controls.getObject());

const menuScreen = document.getElementById('menu-screen');
const hudEl = document.getElementById('hud');
const hintEl = document.getElementById('crosshair-hint');
const shopEl = document.getElementById('shop');

document.body.addEventListener('click', () => {
  if (state.joined && state.alive && shopEl.classList.contains('hidden')) {
    controls.lock();
  }
});
controls.addEventListener('lock', () => hintEl.classList.add('hidden'));
controls.addEventListener('unlock', () => {
  if (state.joined && state.alive) hintEl.classList.remove('hidden');
});

const keys = {};
window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
  onKeyPress(e.code);
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });

// ---------------- Game / network state ----------------
const state = {
  joined: false,
  selfId: null,
  roomId: null,
  team: null,
  hp: 100,
  alive: true,
  credits: 800,
  weapon: 'sidearm',
  ammo: getWeapon('sidearm').mag,
  phase: 'buy',
  round: 1,
  score: { attackers: 0, defenders: 0 },
  canShootAt: 0,
  onGround: false,
  bomb: { planted: false, site: null },
  thirdPerson: false,
};

let localMesh = null; // only shown in third-person mode; invisible to the local viewer in first-person
const THIRD_PERSON_DISTANCE = 5;
const THIRD_PERSON_HEIGHT_OFFSET = 0.9;

const remotePlayers = new Map(); // socketId -> RemotePlayer
const net = new NetworkManager();

// ---------------- Join flow ----------------
function getRoomFromURL() {
  return new URLSearchParams(window.location.search).get('room');
}

window.addEventListener('DOMContentLoaded', () => {
  const r = getRoomFromURL();
  if (r) document.getElementById('room-input').value = r;
});

function attemptJoin() {
  const name = document.getElementById('name-input').value.trim() || undefined;
  const roomInput = document.getElementById('room-input').value.trim().toUpperCase();
  const roomId = roomInput || getRoomFromURL() || undefined;
  net.join(roomId, name);
}
document.getElementById('join-btn').addEventListener('click', attemptJoin);
['name-input', 'room-input'].forEach((id) => {
  document.getElementById(id).addEventListener('keydown', (e) => {
    if (e.key === 'Enter') attemptJoin();
  });
});

net.on('joined', (data) => {
  state.joined = true;
  state.selfId = data.selfId;
  state.roomId = data.roomId;

  const url = new URL(window.location.href);
  url.searchParams.set('room', data.roomId);
  window.history.replaceState({}, '', url);

  const self = data.snapshot.players.find((p) => p.id === data.selfId);
  state.team = self.team;
  state.hp = self.hp;
  state.credits = self.credits;
  state.weapon = self.weapon;
  state.ammo = getWeapon(self.weapon).mag;
  state.phase = data.snapshot.phase;
  state.round = data.snapshot.round;

  data.snapshot.players.forEach((p) => {
    if (p.id !== state.selfId) spawnRemote(p);
  });

  localMesh = createPlayerMesh(self.team);
  localMesh.visible = false;
  scene.add(localMesh);

  placePlayerAtSpawn(self.team);

  menuScreen.classList.add('hidden');
  hudEl.classList.remove('hidden');
  hintEl.classList.remove('hidden');
  initShop(net, state);
  HUD.updateHP(state.hp);
  HUD.updateCredits(state.credits);
  HUD.updateWeapon(state.weapon, state.ammo, getWeapon(state.weapon).mag);
  HUD.updatePhase(state.phase, 30, state.round);
});

function placePlayerAtSpawn(team) {
  const z = team === 'attackers' ? 40 : -40;
  playerBody.position.set((Math.random() - 0.5) * 6, 3, z);
  playerBody.velocity.set(0, 0, 0);
}

function spawnRemote(p) {
  const rp = new RemotePlayer(scene, p);
  rp.setAlive(p.alive);
  remotePlayers.set(p.id, rp);
}

net.on('player_joined', (p) => { if (p.id !== state.selfId) spawnRemote(p); });
net.on('player_left', ({ id }) => {
  const rp = remotePlayers.get(id);
  if (rp) { rp.dispose(scene); remotePlayers.delete(id); }
});
net.on('player_moved', (d) => {
  const rp = remotePlayers.get(d.id);
  if (rp) rp.pushSnapshot(d.position, d.rotation);
});
net.on('player_shoot', (d) => spawnTracer(d.origin, d.direction));

net.on('player_damaged', (d) => {
  if (d.targetId === state.selfId) {
    state.hp = d.hp;
    HUD.updateHP(state.hp);
    flashDamage();
  }
});

net.on('player_eliminated', (d) => {
  const shooterName = d.byId === state.selfId ? 'YOU' : (remotePlayers.get(d.byId)?.name || 'Enemy');
  const targetName = d.targetId === state.selfId ? 'YOU' : (remotePlayers.get(d.targetId)?.name || 'Enemy');
  HUD.pushKillFeed(`${shooterName} ⚔ ${targetName}${d.headshot ? ' (HEADSHOT)' : ''}`);

  if (d.targetId === state.selfId) {
    state.alive = false;
    controls.unlock();
    HUD.setDeathOverlay(true);
  }
  const rp = remotePlayers.get(d.targetId);
  if (rp) rp.setAlive(false);
});

net.on('round_start', (snapshot) => {
  state.phase = 'buy';
  state.round = snapshot.round;
  state.alive = true;
  state.hp = 100;
  state.bomb = { planted: false, site: null };
  HUD.updateHP(state.hp);
  HUD.setDeathOverlay(false);
  HUD.hideActionProgress();
  placePlayerAtSpawn(state.team);
  refreshShopAffordability(state);
});

net.on('phase_change', (d) => {
  state.phase = d.phase;
  if (state.phase === 'round') closeShop();
});
net.on('phase_tick', (d) => {
  state.phase = d.phase;
  HUD.updatePhase(d.phase, d.timeLeft, state.round);
});

net.on('round_end', (d) => {
  if (d.winningTeam === 'attackers') state.score.attackers++; else state.score.defenders++;
  HUD.updateScore(state.score.attackers, state.score.defenders);
  const reasonText = {
    elimination: '전멸', bomb_exploded: '폭탄 폭발', bomb_defused: '폭탄 해체', time_expired: '시간 종료',
  }[d.reason] || d.reason;
  HUD.pushKillFeed(`${d.winningTeam === 'attackers' ? '공격팀' : '수비팀'} 승리 — ${reasonText}`);
});

net.on('economy_update', (d) => {
  state.credits = d.credits;
  state.weapon = d.weapon;
  state.ammo = getWeapon(state.weapon).mag;
  HUD.updateCredits(state.credits);
  HUD.updateWeapon(state.weapon, state.ammo, getWeapon(state.weapon).mag);
  refreshShopAffordability(state);
});

net.on('bomb_planted', ({ site }) => {
  state.bomb = { planted: true, site };
  HUD.pushKillFeed(`폭탄이 ${site} 사이트에 설치되었습니다!`);
});

net.on('room_update', (snapshot) => {
  const self = snapshot.players.find((p) => p.id === state.selfId);
  if (self) {
    state.hp = self.hp;
    HUD.updateHP(state.hp);
  }
});

// ---------------- Input: shop / plant / defuse ----------------
function onKeyPress(code) {
  if (!state.joined) return;
  if (code === 'KeyB') {
    if (shopEl.classList.contains('hidden')) openShop(); else closeShop();
  }
  if (code === 'KeyE') {
    tryPlantOrDefuse();
  }
  if (code === 'KeyV') {
    state.thirdPerson = !state.thirdPerson;
  }
}
document.getElementById('shop-close').addEventListener('click', closeShop);

document.getElementById('copy-link-btn').addEventListener('click', () => {
  navigator.clipboard?.writeText(window.location.href).then(() => {
    HUD.pushKillFeed('초대 링크가 복사되었습니다!');
  }).catch(() => {});
});

canvas.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  if (!controls.isLocked || !state.alive || state.phase !== 'round') return;
  tryShoot();
});

let actionHold = null;
function tryPlantOrDefuse() {
  if (!state.alive || state.phase !== 'round' || actionHold) return;
  const pos = playerBody.position;
  const site = pointInAnySite(pos);

  if (state.team === 'attackers' && !state.bomb.planted && site) {
    HUD.showActionProgress('설치 중...');
    const t0 = performance.now();
    actionHold = setInterval(() => {
      const pct = Math.min(100, ((performance.now() - t0) / 4000) * 100);
      HUD.setActionProgress(pct);
      if (pct >= 100) {
        clearInterval(actionHold);
        actionHold = null;
        HUD.hideActionProgress();
        net.plantBomb(site);
      }
    }, 100);
  } else if (state.team === 'defenders' && state.bomb.planted) {
    HUD.showActionProgress('해체 중...');
    net.defuseBomb();
    const t0 = performance.now();
    actionHold = setInterval(() => {
      const pct = Math.min(100, ((performance.now() - t0) / 7000) * 100);
      HUD.setActionProgress(pct);
      if (pct >= 100) {
        clearInterval(actionHold);
        actionHold = null;
        HUD.hideActionProgress();
      }
    }, 100);
  }
}

function pointInAnySite(pos) {
  for (const site of Object.keys(SITE_ZONES)) {
    const z = SITE_ZONES[site];
    if (pos.x >= z.minX && pos.x <= z.maxX && pos.z >= z.minZ && pos.z <= z.maxZ) return site;
  }
  return null;
}

function updateSitePrompt() {
  if (!state.alive || state.phase !== 'round') { HUD.setSitePrompt(null); return; }
  const site = pointInAnySite(playerBody.position);
  if (state.team === 'attackers' && !state.bomb.planted && site) {
    HUD.setSitePrompt(`[E] ${site} 사이트에 폭탄 설치`);
  } else if (state.team === 'defenders' && state.bomb.planted) {
    HUD.setSitePrompt('[E] 폭탄 해체');
  } else {
    HUD.setSitePrompt(null);
  }
}

// ---------------- Shooting: raycast against remote player meshes ----------------
const raycaster = new THREE.Raycaster();
function tryShoot() {
  const w = getWeapon(state.weapon);
  const now = performance.now();
  const fireInterval = 1000 / w.fireRate;
  if (now < state.canShootAt) return;
  if (state.ammo <= 0) return;
  state.canShootAt = now + fireInterval;
  state.ammo -= 1;
  HUD.updateWeapon(state.weapon, state.ammo, w.mag);

  // Simple recoil kick (PointerLockControls re-derives from the current
  // camera quaternion on the next mousemove, so this blends naturally).
  camera.rotation.x += w.recoil * (0.5 + Math.random() * 0.5);

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const direction = camera.getWorldDirection(new THREE.Vector3());
  net.sendShoot(
    { x: origin.x, y: origin.y, z: origin.z },
    { x: direction.x, y: direction.y, z: direction.z }
  );
  spawnTracer(origin, direction);

  raycaster.set(origin, direction);
  const targets = [];
  remotePlayers.forEach((rp) => { if (rp.alive) targets.push(rp.mesh); });
  const hits = raycaster.intersectObjects(targets, true);
  if (hits.length > 0) {
    const hit = hits[0];
    const headshot = hit.object.name === 'head';
    const group = hit.object.parent;
    for (const [id, rp] of remotePlayers) {
      if (rp.mesh === group) {
        const dmg = headshot ? Math.round(w.damage * 2.5) : w.damage;
        net.reportHit(id, dmg, headshot);
        break;
      }
    }
  }
}

function spawnTracer(origin, direction) {
  const end = new THREE.Vector3(
    origin.x + direction.x * 60,
    origin.y + direction.y * 60,
    origin.z + direction.z * 60
  );
  const geo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(origin.x, origin.y, origin.z), end,
  ]);
  const mat = new THREE.LineBasicMaterial({ color: 0xfff59e, transparent: true, opacity: 0.9 });
  const line = new THREE.Line(geo, mat);
  scene.add(line);
  setTimeout(() => scene.remove(line), 80);
}

function flashDamage() {
  const flash = document.createElement('div');
  flash.className = 'damage-flash';
  document.body.appendChild(flash);
  setTimeout(() => flash.remove(), 200);
}

// ---------------- Movement (WASD + cannon-es collision) ----------------
const MOVE_SPEED = 9;
const JUMP_FORCE = 8;

function updateMovement() {
  if (!state.alive) return;

  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward);
  forward.y = 0;
  forward.normalize();
  const right = new THREE.Vector3().crossVectors(forward, camera.up).normalize();

  let moveX = 0;
  let moveZ = 0;
  if (keys['KeyW']) moveZ += 1;
  if (keys['KeyS']) moveZ -= 1;
  if (keys['KeyD']) moveX += 1;
  if (keys['KeyA']) moveX -= 1;

  const speed = MOVE_SPEED * (keys['ShiftLeft'] ? 0.5 : 1);
  const dir = new THREE.Vector3();
  dir.addScaledVector(forward, moveZ).addScaledVector(right, moveX);
  if (dir.lengthSq() > 0) dir.normalize().multiplyScalar(speed);

  playerBody.velocity.x = dir.x;
  playerBody.velocity.z = dir.z;

  // Ground check via a short downward raycast against the physics world.
  const from = new CANNON.Vec3(playerBody.position.x, playerBody.position.y, playerBody.position.z);
  const to = new CANNON.Vec3(
    playerBody.position.x, playerBody.position.y - (PLAYER_HEIGHT / 2 + 0.15), playerBody.position.z
  );
  const result = new CANNON.RaycastResult();
  world.raycastClosest(from, to, {}, result);
  state.onGround = result.hasHit;

  if (keys['Space'] && state.onGround) {
    playerBody.velocity.y = JUMP_FORCE;
  }
}

// First-person eye position is set on `camera` just before this runs (see
// animate()). In third-person mode we then pull the camera back behind the
// player along the look direction, using a raycast against the map's real
// geometry so the camera never clips through walls/crates.
function updateCameraMode() {
  const eyePos = camera.position.clone();

  if (localMesh) {
    localMesh.position.set(
      playerBody.position.x,
      playerBody.position.y - PLAYER_HEIGHT / 2 + 0.05,
      playerBody.position.z
    );
    localMesh.rotation.y = camera.rotation.y;
    localMesh.visible = state.thirdPerson && state.alive;
  }

  if (!state.thirdPerson) return; // camera already sitting at the eye position

  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward); // orientation only — unaffected by the position set above

  const desired = eyePos.clone()
    .addScaledVector(forward, -THIRD_PERSON_DISTANCE)
    .add(new THREE.Vector3(0, THIRD_PERSON_HEIGHT_OFFSET, 0));

  const toDesired = desired.clone().sub(eyePos);
  const maxDist = toDesired.length();
  const dir = toDesired.clone().normalize();

  raycaster.set(eyePos, dir);
  raycaster.far = maxDist;
  const hits = raycaster.intersectObjects(collidableMeshes, false);
  const finalDist = hits.length > 0 ? Math.max(0.6, hits[0].distance - 0.3) : maxDist;

  camera.position.copy(eyePos).addScaledVector(dir, finalDist);
}

// ---------------- Main loop ----------------
const clock = new THREE.Clock();
let netAccumulator = 0;
let promptAccumulator = 0;
const NET_SEND_INTERVAL = 0.05; // 50ms => satisfies the <=50ms sync requirement

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(0.05, clock.getDelta());

  if (state.joined) {
    updateMovement();
    world.step(1 / 60, dt, 5);

    controls.getObject().position.set(
      playerBody.position.x,
      playerBody.position.y + PLAYER_HEIGHT / 2 - 0.2,
      playerBody.position.z
    );
    updateCameraMode();

    netAccumulator += dt;
    if (netAccumulator >= NET_SEND_INTERVAL) {
      netAccumulator = 0;
      const moving = keys['KeyW'] || keys['KeyA'] || keys['KeyS'] || keys['KeyD'];
      net.sendMove(
        { x: playerBody.position.x, y: playerBody.position.y, z: playerBody.position.z },
        { y: camera.rotation.y },
        state.onGround ? (moving ? 'run' : 'idle') : 'air'
      );
    }

    promptAccumulator += dt;
    if (promptAccumulator >= 0.2) {
      promptAccumulator = 0;
      updateSitePrompt();
    }

    const now = performance.now();
    remotePlayers.forEach((rp) => rp.update(now));
  }

  renderer.render(scene, camera);
}
animate();
