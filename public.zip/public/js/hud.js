// hud.js
// Pure DOM-manipulation helpers for the in-game HUD. Kept separate from
// main.js so the game-loop / networking code doesn't get tangled up with
// UI bookkeeping.

export function updateHP(hp) {
  document.getElementById('hp-bar').style.width = Math.max(0, hp) + '%';
  document.getElementById('hp-text').textContent = Math.max(0, Math.round(hp));
}

export function updateCredits(credits) {
  document.getElementById('credits-text').textContent = '💰 ' + credits;
  document.getElementById('shop-credits').textContent = '💰 ' + credits;
}

export function updateWeapon(weapon, ammo, magSize) {
  document.getElementById('weapon-name').textContent = weapon.toUpperCase();
  document.getElementById('ammo-text').textContent = `${ammo} / ${magSize}`;
}

export function updatePhase(phase, timeLeft, round) {
  const label = { buy: 'BUY PHASE', round: 'ROUND ACTIVE', end: 'ROUND OVER' }[phase] || phase;
  document.getElementById('phase-label').textContent = label;
  const m = Math.floor(timeLeft / 60);
  const s = timeLeft % 60;
  document.getElementById('phase-timer').textContent = `${m}:${String(s).padStart(2, '0')}`;
  document.getElementById('round-label').textContent = `ROUND ${round}`;
}

export function updateScore(atk, def) {
  document.getElementById('score-atk').textContent = atk;
  document.getElementById('score-def').textContent = def;
}

export function pushKillFeed(text) {
  const feed = document.getElementById('kill-feed');
  const row = document.createElement('div');
  row.className = 'kf-row';
  row.textContent = text;
  feed.prepend(row);
  setTimeout(() => row.remove(), 6000);
  while (feed.children.length > 5) feed.removeChild(feed.lastChild);
}

export function showActionProgress(label) {
  const el = document.getElementById('action-progress');
  el.classList.remove('hidden');
  document.getElementById('action-label').textContent = label;
  document.getElementById('action-bar').style.width = '0%';
}

export function setActionProgress(pct) {
  document.getElementById('action-bar').style.width = pct + '%';
}

export function hideActionProgress() {
  document.getElementById('action-progress').classList.add('hidden');
}

export function setSitePrompt(text) {
  const el = document.getElementById('site-prompt');
  if (!text) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  el.textContent = text;
}

export function setDeathOverlay(visible) {
  document.getElementById('death-overlay').classList.toggle('hidden', !visible);
}
