// network.js
// Thin wrapper around the Socket.io client, plus a small snapshot
// interpolation buffer used to smooth out remote players' movement
// between network updates (classic FPS "entity interpolation").

export class NetworkManager {
  constructor() {
    this.socket = io(); // global `io` comes from /socket.io/socket.io.js
    this.selfId = null;
    this.roomId = null;
    this.weapons = {};
    this.listeners = {};
    this._bindCoreEvents();
  }

  on(event, cb) {
    (this.listeners[event] ||= []).push(cb);
  }

  _emitLocal(event, payload) {
    (this.listeners[event] || []).forEach((cb) => cb(payload));
  }

  _bindCoreEvents() {
    const s = this.socket;
    s.on('joined', (data) => {
      this.selfId = data.selfId;
      this.roomId = data.roomId;
      this.weapons = data.weapons;
      this._emitLocal('joined', data);
    });

    [
      'room_update', 'player_joined', 'player_left', 'player_moved', 'player_shoot',
      'player_damaged', 'player_eliminated', 'phase_change', 'phase_tick', 'round_start',
      'round_end', 'economy_update', 'bomb_planted', 'defuse_started', 'chat',
    ].forEach((evt) => s.on(evt, (data) => this._emitLocal(evt, data)));
  }

  join(roomId, name) {
    this.socket.emit('join_room', { roomId, name });
  }

  sendMove(position, rotation, anim) {
    this.socket.emit('move', { position, rotation, anim });
  }

  sendShoot(origin, direction) {
    this.socket.emit('shoot', { origin, direction });
  }

  reportHit(targetId, damage, headshot) {
    this.socket.emit('report_hit', { targetId, damage, headshot });
  }

  buyWeapon(key) {
    this.socket.emit('buy_weapon', key);
  }

  plantBomb(site) {
    this.socket.emit('plant_bomb', { site });
  }

  defuseBomb() {
    this.socket.emit('defuse_bomb');
  }

  sendChat(msg) {
    this.socket.emit('chat', msg);
  }
}

// ---- Snapshot interpolation buffer for one remote player ----
// Every incoming {position, rotation, t} update is pushed onto a small
// history buffer. When rendering, we sample the buffer at
// (now - delayMs) and lerp between the two surrounding snapshots. The
// artificial delay costs a little latency but completely removes the
// jitter/teleporting you'd otherwise see from a ~20Hz update rate.
export class InterpolationBuffer {
  constructor(delayMs = 100) {
    this.delay = delayMs;
    this.snapshots = [];
  }

  push(snapshot) {
    this.snapshots.push(snapshot);
    while (this.snapshots.length > 20) this.snapshots.shift();
  }

  sample(now) {
    const renderTime = now - this.delay;
    const buf = this.snapshots;
    if (buf.length === 0) return null;
    if (buf.length === 1) return buf[0];

    let older = null;
    let newer = null;
    for (let i = 0; i < buf.length - 1; i++) {
      if (buf[i].t <= renderTime && buf[i + 1].t >= renderTime) {
        older = buf[i];
        newer = buf[i + 1];
        break;
      }
    }
    if (!older || !newer) return buf[buf.length - 1]; // out of range: clamp to latest

    const span = newer.t - older.t || 1;
    const alpha = Math.min(1, Math.max(0, (renderTime - older.t) / span));
    return {
      position: {
        x: older.position.x + (newer.position.x - older.position.x) * alpha,
        y: older.position.y + (newer.position.y - older.position.y) * alpha,
        z: older.position.z + (newer.position.z - older.position.z) * alpha,
      },
      rotation: {
        y: older.rotation.y + shortestAngleDelta(older.rotation.y, newer.rotation.y) * alpha,
      },
    };
  }
}

function shortestAngleDelta(a, b) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}
