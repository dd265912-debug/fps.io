// economy.js
// Buy-phase shop overlay. Renders the weapon catalog grouped by tier and
// wires each card's click to a `buy_weapon` request; the server is the
// final authority on whether the purchase is allowed.

import { WEAPON_CATALOG } from './weapons.js';

export function initShop(net, state) {
  const grid = document.getElementById('shop-grid');
  const tiers = ['Pistol', 'SMG', 'Rifle', 'Heavy'];

  grid.innerHTML = '';
  tiers.forEach((tier) => {
    const col = document.createElement('div');
    col.className = 'shop-col';
    const h = document.createElement('h3');
    h.textContent = tier.toUpperCase();
    col.appendChild(h);

    WEAPON_CATALOG.filter((w) => w.tier === tier).forEach((w) => {
      const card = document.createElement('button');
      card.className = 'weapon-card';
      card.dataset.key = w.key;
      card.innerHTML = `
        <div class="wc-name">${w.name}</div>
        <div class="wc-stats">DMG ${w.damage} · MAG ${w.mag}</div>
        <div class="wc-price">${w.price === 0 ? 'FREE' : '💰 ' + w.price}</div>
      `;
      card.addEventListener('click', () => {
        if (state.credits < w.price) return;
        net.buyWeapon(w.key);
      });
      col.appendChild(card);
    });
    grid.appendChild(col);
  });

  refreshShopAffordability(state);
}

export function refreshShopAffordability(state) {
  document.querySelectorAll('.weapon-card').forEach((card) => {
    const w = WEAPON_CATALOG.find((x) => x.key === card.dataset.key);
    if (!w) return;
    card.classList.toggle('disabled', state.credits < w.price);
    card.classList.toggle('owned', state.weapon === w.key);
  });
}

export function openShop() {
  document.getElementById('shop').classList.remove('hidden');
  document.exitPointerLock?.();
}

export function closeShop() {
  document.getElementById('shop').classList.add('hidden');
}
